#!/bin/bash
if [ -f /etc/httpd/conf/httpd.conf]
then
rm /etc/httpd/conf/httpd.conf 
fi
